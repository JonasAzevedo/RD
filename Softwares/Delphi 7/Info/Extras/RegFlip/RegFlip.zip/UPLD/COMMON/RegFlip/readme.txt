***RegFlip.exe***

Copyright 2000 Inprise Corp.

***Use***

RegFlip will allow you to add, remove, and edit Just In Time Debuggers
in the Windows registry.

1.) All of the checked entries are JITs that are currently selectable
by Windows to be used, and unchecked are known debuggers that are saved
into the registry to allow quick switching of registered JITs.

2.) Once you have selected a registry entry from the list, in order to
edit it you me click the Edit Key Button.

3.) Deleting unwanted keys:  Just right mouse click on the List of keys
or use the Delete Key from the keyboard.

4.) After you have made all wanted changes to your registry, click 
Write Keys to apply them.

Note: No changes are made to the registry until Write Keys is clicked.
